import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '@txnlab/use-wallet-react';
import '../styles/dashboard.css';
import QRModal from '../components/QRModal';
import RecordSlider from '../components/RecordSlider';
import UploadRecordModal from '../components/UploadRecordModal';
import {
  auditLog,
  consents,
  inboundRequests,
  medicalRecords,
  patients,
  getPatientById,
  recordTypeLabel,
  type AuditEntry,
  type Consent,
  type MedicalRecord,
  type Patient,
} from '../lib/mockdb';
import { makeInitials, normalizeText, sortByTimeline, uniqueCount } from '../lib/dashboardHelpers';
import { useSnackbar } from 'notistack';
import { MedicalRecordsClient } from '../contracts/MedicalRecords';
import { getAlgorandClientFromViteEnvironment } from '../utils/network/getAlgoClientConfigs';
import { buildPrescriptionBoxReferences, createPrescriptionCid, fetchAllPatientRecords, findPatientByIdentifier, resolvePatient } from '../lib/medicalPortalData';
import { useMedicalRecords } from '../hooks/useMedicalRecords';
import { usePrescriptionUpload } from '../hooks/usePrescriptionUpload';
import {
  subscribeToSharedAccessRequests,
  updateSharedAccessRequestStatus,
  type AccessRequestStatus,
  type SharedAccessRequest,
} from '../lib/realtimeAccessRequests';
import { useAccessRequests } from '../hooks/useAccessRequests';

type ConsentStatus = 'active' | 'pending' | 'expired';
type ConsentTab = 'active' | 'pending' | 'expired';
type RequestStatus = 'pending' | 'approved' | 'rejected';

interface DoctorRequest {
  id: string;
  patient: Patient;
  scope: string;
  reason: string;
  status: RequestStatus;
  requestedAt: string;
}

const consentStorageKey = 'Aegis-doctor-consent-statuses';

const DEFAULT_PATIENT = getPatientById('p1');

const loadConsentStatuses = (fallback: Consent[]) => {
  if (typeof window === 'undefined') {
    return Object.fromEntries(fallback.map((consent) => [consent.id, consent.status])) as Record<string, ConsentStatus>;
  }

  try {
    const raw = window.localStorage.getItem(consentStorageKey);
    if (!raw) {
      return Object.fromEntries(fallback.map((consent) => [consent.id, consent.status])) as Record<string, ConsentStatus>;
    }

    const parsed = JSON.parse(raw) as Record<string, ConsentStatus>;
    return fallback.reduce<Record<string, ConsentStatus>>((accumulator, consent) => {
      accumulator[consent.id] = parsed[consent.id] ?? consent.status;
      return accumulator;
    }, {});
  } catch {
    return Object.fromEntries(fallback.map((consent) => [consent.id, consent.status])) as Record<string, ConsentStatus>;
  }
};

const toDoctorRequest = (request: SharedAccessRequest): DoctorRequest => {
  const patient = patients.find((candidate) => candidate.id === request.patientId) ?? DEFAULT_PATIENT;
  return {
    id: request.id,
    patient,
    scope: request.scope,
    reason: request.reason,
    status: request.status,
    requestedAt: request.requestedAt,
  };
};

export default function DoctorDashboard() {
  const { activeAddress, transactionSigner, wallets } = useWallet();
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const { submitRequest: submitBlockchainRequest } = useAccessRequests();
  const [activeNav, setActiveNav] = useState('overview');
  const [showLogoutMenu, setShowLogoutMenu] = useState(false);
  const [activeTab, setActiveTab] = useState<ConsentTab>('active');
  const [searchQuery, setSearchQuery] = useState('');
  const [consentStatuses, setConsentStatuses] = useState<Record<string, ConsentStatus>>(() => ({}) as Record<string, ConsentStatus>);
  const [activityFeed, setActivityFeed] = useState<AuditEntry[]>(auditLog);
  const [viewerRecords, setViewerRecords] = useState<MedicalRecord[]>([]);
  const [viewerIndex, setViewerIndex] = useState(0);
  const [shareRecord, setShareRecord] = useState<MedicalRecord | null>(null);
  const [requestPatient, setRequestPatient] = useState(DEFAULT_PATIENT.shortId);
  const [requestScope, setRequestScope] = useState('LAB_RESULTS');
  const [requestReason, setRequestReason] = useState('Requesting access for ongoing care coordination.');
  const [requestQueue, setRequestQueue] = useState<DoctorRequest[]>([]);
  const [liveRecords, setLiveRecords] = useState<MedicalRecord[]>(medicalRecords);
  const [prescriptionTarget, setPrescriptionTarget] = useState(DEFAULT_PATIENT.shortId);
  const [prescriptionMedication, setPrescriptionMedication] = useState('Amoxicillin 500mg');
  const [prescriptionDosage, setPrescriptionDosage] = useState('1 tablet three times daily for 10 days');
  const [prescriptionInstructions, setPrescriptionInstructions] = useState('Take after meals and complete the full course.');
  const [prescriptionNotes, setPrescriptionNotes] = useState('');
  const [prescriptionSubmitting, setPrescriptionSubmitting] = useState(false);
  const [prescriptionFeedback, setPrescriptionFeedback] = useState('');
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [selectedPatientAddress, setSelectedPatientAddress] = useState('');

  const algorand = useMemo(() => getAlgorandClientFromViteEnvironment(), []);
  const medicalAppId = Number(import.meta.env.VITE_MEDICAL_RECORDS_APP_ID || 0);

  const patient = DEFAULT_PATIENT;

  // Fetch all patient records for doctor view
  const { records: fetchedRecords, prescriptions: fetchedPrescriptions, allRecords, loading: recordsLoading, refetch: refetchRecords } = useMedicalRecords(activeAddress, patient);

  useEffect(() => {
    let cancelled = false;

    const syncRecords = async () => {
      try {
        const records = await fetchAllPatientRecords();
        if (!cancelled && records.length > 0) {
          setLiveRecords(records);
        }
      } catch {
        if (!cancelled) {
          setLiveRecords(medicalRecords);
        }
      }
    };

    syncRecords();
    const interval = setInterval(syncRecords, 45000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    setConsentStatuses(loadConsentStatuses(consents));
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToSharedAccessRequests((requests) => {
      setRequestQueue(requests.filter((request) => request.requestedByRole === 'doctor').map(toDoctorRequest));
    });

    return unsubscribe;
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || Object.keys(consentStatuses).length === 0) {
      return;
    }

    window.localStorage.setItem(consentStorageKey, JSON.stringify(consentStatuses));
  }, [consentStatuses]);

  const navLabels: Record<string, string> = {
    overview: 'Overview',
    patients: 'My Patients',
    consents: 'My Consents',
    records: 'Accessible Records',
    requests: 'New Request',
    schedule: 'Schedule',
    audit: 'My Audit Trail',
    settings: 'Settings',
  };

  const currentNavLabel = navLabels[activeNav] ?? 'Overview';

  useEffect(() => {
    const revealEls = Array.from(document.querySelectorAll<HTMLElement>('.reveal'));
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const io = prefersReducedMotion
      ? null
      : new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                entry.target.classList.add('in');
                io?.unobserve(entry.target);
              }
            });
          },
          { threshold: 0.1 }
        );

    if (prefersReducedMotion) {
      revealEls.forEach((element) => element.classList.add('in'));
    } else {
      revealEls.forEach((element) => io?.observe(element));
    }

    return () => {
      io?.disconnect();
    };
  }, [activeNav]);

  const consentRows = useMemo(() => {
    return consents.map((consent) => ({
      ...consent,
      status: consentStatuses[consent.id] ?? consent.status,
    }));
  }, [consentStatuses]);

  const accessibleRecords = useMemo(() => {
    const activePatientIds = new Set(
      consentRows.filter((consent) => consent.status === 'active').map((consent) => consent.patientId)
    );

    return sortByTimeline(
      liveRecords.filter((record) => activePatientIds.has(record.patientId)),
      (record) => record.date
    );
  }, [consentRows, liveRecords]);

  const activePatients = uniqueCount(accessibleRecords, (record) => record.patientId);
  const activeConsents = consentRows.filter((consent) => consent.status === 'active').length;
  const pendingConsents = consentRows.filter((consent) => consent.status === 'pending').length;
  const expiringConsents = consentRows.filter((consent) => consent.status === 'active' && consent.remaining !== 'key dissolved').length;
  const staffCount = uniqueCount(accessibleRecords, (record) => record.uploadedBy);

  const filteredConsents = useMemo(() => {
    const query = normalizeText(searchQuery);

    return consentRows.filter((consent) => {
      const matchesTab = consent.status === activeTab;
      const matchesQuery = !query || [consent.grantedTo, consent.scopeLabel, consent.issuedAt, consent.expiresAt, consent.remaining]
        .some((value) => normalizeText(value).includes(query));

      return matchesTab && matchesQuery;
    });
  }, [activeTab, consentRows, searchQuery]);

  const filteredRecords = useMemo(() => {
    const query = normalizeText(searchQuery);

    return accessibleRecords.filter((record) => {
      if (!query) return true;

      return [record.title, record.description, record.uploadedBy, record.uploadedByRole, record.hospital, recordTypeLabel[record.type]]
        .some((value) => normalizeText(value).includes(query));
    });
  }, [accessibleRecords, searchQuery]);

  const recentRecords = filteredRecords.slice(0, 6);

  const scheduleItems = useMemo(() => {
    const upcoming = consentRows
      .filter((consent) => consent.status === 'active' || consent.status === 'pending')
      .slice(0, 3)
      .map((consent) => ({
        label: consent.scopeLabel,
        detail: consent.grantedTo,
        status: consent.status,
      }));

    const recordDriven = recentRecords.slice(0, 3).map((record) => ({
      label: record.title,
      detail: record.hospital,
      status: 'active' as const,
    }));

    return [...upcoming, ...recordDriven].slice(0, 4);
  }, [consentRows, recentRecords]);

  const openRecordViewer = useCallback(
    (record: MedicalRecord) => {
      const viewerSource = filteredRecords.length > 0 ? filteredRecords : accessibleRecords;
      const index = viewerSource.findIndex((candidate) => candidate.id === record.id);
      setViewerRecords(viewerSource);
      setViewerIndex(index >= 0 ? index : 0);
    },
    [accessibleRecords, filteredRecords]
  );

  const mutateConsent = useCallback(
    (consentId: string, nextStatus: ConsentStatus, reason: string) => {
      const consent = consentRows.find((entry) => entry.id === consentId);
      if (!consent) {
        return;
      }

      setConsentStatuses((current) => ({ ...current, [consentId]: nextStatus }));
      setActivityFeed((current) => [
        {
          id: `consent-${consentId}-${Date.now()}`,
          action: nextStatus === 'active' ? 'CONSENT_GRANT' : 'CONSENT_REVOKE',
          actor: patient.name,
          actorRole: 'Patient',
          subject: consent.grantedTo,
          detail: `${nextStatus.toUpperCase()} · ${reason} · ${consent.scopeLabel}`,
          timestamp: new Date().toLocaleString(),
          txHash: consent.txHash,
          color: nextStatus === 'active' ? 'lime' : 'coral',
        },
        ...current,
      ]);
      enqueueSnackbar(`${consent.grantedTo} consent ${nextStatus}.`, { variant: nextStatus === 'active' ? 'success' : 'warning' });
    },
    [consentRows, enqueueSnackbar, patient.name]
  );

  const submitRequest = useCallback(async () => {
    const target = patients.find((candidate) => candidate.shortId === requestPatient || candidate.name === requestPatient);
    if (!target) {
      enqueueSnackbar('Select a valid patient short ID or name.', { variant: 'error' });
      return;
    }

    const doctorName = activeAddress
      ? `${activeAddress.slice(0, 6)}...${activeAddress.slice(-4)}`
      : 'Dr. Hanwa, K.';

    const nextRequest = await submitBlockchainRequest({
      patientId: target.id,
      patientAddress: target.walletAddress,
      requestedBy: doctorName,
      requestedByRole: 'doctor',
      requestedByAvatar: activeAddress ? activeAddress.slice(0, 2).toUpperCase() : 'KH',
      requestedByColor: 'coral',
      scope: requestScope,
      reason: requestReason,
      isEmergency: false,
    });

    if (!nextRequest) return;

    setActivityFeed((current) => [
      {
        id: `request-${nextRequest.id}`,
        action: 'REQUEST',
        actor: doctorName,
        actorRole: 'Clinician',
        subject: target.name,
        detail: `REQUEST · ${requestScope} · ${requestReason}${nextRequest.blockchainRequestId ? ` · Chain#${nextRequest.blockchainRequestId}` : ''}`,
        timestamp: nextRequest.requestedAt,
        txHash: nextRequest.blockchainRequestId ?? '',
        color: 'sky',
      },
      ...current,
    ]);
  }, [enqueueSnackbar, requestPatient, requestReason, requestScope, submitBlockchainRequest, activeAddress]);

  const updateRequestStatus = useCallback((requestId: string, nextStatus: RequestStatus) => {
    updateSharedAccessRequestStatus(requestId, nextStatus as AccessRequestStatus);
    setActivityFeed((current) => [
      {
        id: `req-${requestId}-${Date.now()}`,
        action: nextStatus === 'approved' ? 'CONSENT_GRANT' : 'CONSENT_REVOKE',
        actor: patient.name,
        actorRole: 'Patient',
        subject: requestId,
        detail: `${nextStatus.toUpperCase()} · clinician request`,
        timestamp: new Date().toLocaleString(),
        txHash: '',
        color: nextStatus === 'approved' ? 'lime' : 'coral',
      },
      ...current,
    ]);
  }, [patient.name]);

  const handleLogout = useCallback(async () => {
    setShowLogoutMenu(false);

    try {
      // Disconnect all wallets
      if (wallets && wallets.length > 0) {
        wallets.forEach(w => w.disconnect());
      }

      // Clear any local storage related to wallet/session
      if (typeof window !== 'undefined') {
        // Clear wallet-related session data
        sessionStorage.removeItem('Aegis_proxy_addr');
        sessionStorage.removeItem('Aegis_proxy_id');
        localStorage.removeItem('Aegis-doctor-consent-statuses');
      }

      // Navigate with a slight delay and force page reload
      setTimeout(() => {
        window.location.replace('/');
      }, 200);
    } catch (err) {
      console.error('[DoctorDashboard] Logout error:', err);
      // Force redirect even if disconnect fails
      window.location.replace('/');
    }
  }, [wallets]);

  const filteredRequests = requestQueue.filter((request) => {
    const query = normalizeText(searchQuery);
    if (!query) return true;

    return [request.patient.name, request.patient.shortId, request.scope, request.reason, request.status]
      .some((value) => normalizeText(value).includes(query));
  });

  const heroSummary = `${activeConsents} active consents, ${expiringConsents} expiring windows, and ${accessibleRecords.length} accessible records.`;

  // Use prescription upload hook
  const { uploadPrescription, uploading: prescriptionUploading } = usePrescriptionUpload();

  const submitPrescription = useCallback(async () => {
    if (!activeAddress) {
      enqueueSnackbar('Connect a wallet first', { variant: 'error' });
      return;
    }

    setPrescriptionFeedback('');

    try {
      const { patient: resolvedPatient, walletAddress } = await resolvePatient(prescriptionTarget);

      await uploadPrescription({
        patientAddress: walletAddress,
        patientName: resolvedPatient.name,
        medication: prescriptionMedication,
        dosage: prescriptionDosage,
        instructions: prescriptionInstructions,
        notes: prescriptionNotes,
        providerName: activeAddress,
      });

      setPrescriptionFeedback(`Prescription uploaded for ${resolvedPatient.name}`);
      setPrescriptionMedication('Amoxicillin 500mg');
      setPrescriptionDosage('1 tablet three times daily for 10 days');
      setPrescriptionInstructions('Take after meals and complete the full course.');
      setPrescriptionNotes('');

      // Refresh records
      setLiveRecords(await fetchAllPatientRecords());
    } catch (error: any) {
      setPrescriptionFeedback(error?.message ?? 'Failed to upload prescription.');
    }
  }, [activeAddress, prescriptionDosage, prescriptionInstructions, prescriptionMedication, prescriptionNotes, prescriptionTarget, uploadPrescription, enqueueSnackbar]);

  const renderDoctorTabContent = () => {
    if (activeNav === 'patients') {
      return (
        <div style={{ padding: '40px' }}>
          <div style={{ marginBottom: '24px' }}>
            <h2 style={{ margin: '0 0 8px 0' }}>My Patients</h2>
            <p style={{ margin: 0, color: 'var(--ink-2)', fontSize: '14px' }}>{patients.length} patients in your care</p>
          </div>
          <table className="tbl">
            <thead>
              <tr>
                <th>Patient Name</th>
                <th>Short ID</th>
                <th>Blood Group</th>
                <th>DOB</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {patients.map((p) => (
                <tr key={p.id}>
                  <td>
                    <div className="avn">
                      <div className="av" data-c={p.avatarColor}>{makeInitials(p.name)}</div>
                      <div>
                        <div className="nm">{p.name}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ fontFamily: 'var(--mono)', fontSize: '12px' }}>{p.shortId}</td>
                  <td style={{ fontSize: '12px', color: 'var(--ink-2)' }}>{p.bloodGroup}</td>
                  <td style={{ fontSize: '12px', color: 'var(--ink-2)' }}>{p.dob}</td>
                  <td className="actions-cell">
                    <button className="ibtn lime" title="Upload record" onClick={() => { setSelectedPatientAddress(p.walletAddress); setUploadModalOpen(true); }}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" /></svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }

    if (activeNav === 'settings') {
      return (
        <div style={{ padding: '40px' }}>
          <h2 style={{ margin: '0 0 24px 0' }}>Settings</h2>
          <div style={{ maxWidth: '500px' }}>
            <div style={{ padding: '20px', background: 'var(--bg-2)', borderRadius: '12px', border: '1px solid var(--line)' }}>
              <h3 style={{ margin: '0 0 12px 0' }}>Profile</h3>
              <div style={{ display: 'grid', gap: '12px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '12px', color: 'var(--ink-2)', marginBottom: '4px' }}>Name</label>
                  <input value={patient.name} disabled style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '14px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '12px', color: 'var(--ink-2)', marginBottom: '4px' }}>Specialization</label>
                  <input value="Internal Medicine" disabled style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '14px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '12px', color: 'var(--ink-2)', marginBottom: '4px' }}>License ID</label>
                  <input value="LIC-123456" disabled style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '14px' }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return <div style={{ padding: '40px' }}>No content available for this section.</div>;
  };

  return (
    <div className="grain">
      <div className="blobs">
        <i className="b1" style={{ background: 'var(--coral)' }} />
        <i className="b2" style={{ background: 'var(--lime)' }} />
        <i className="b3" />
      </div>

      <div className="app">
        <aside>
          <div className="brand">
            <div className="mark" style={{ background: 'var(--ink)' }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M6 2v6a6 6 0 0 0 12 0V2" />
                <circle cx="18" cy="16" r="3" />
                <path d="M12 8v6" />
              </svg>
            </div>
            <b>Dr. Hanwa <span>/ Clinician</span></b>
          </div>

          <div className="navgroup">
            <h5>Clinical</h5>
            <div className={`navitem ${activeNav === 'overview' ? 'active' : ''}`} onClick={() => setActiveNav('overview')}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>
              Overview
            </div>
            <div className={`navitem ${activeNav === 'patients' ? 'active' : ''}`} onClick={() => setActiveNav('patients')}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></svg>
              My Patients<span className="badge">{activePatients}</span>
            </div>
            <div className={`navitem ${activeNav === 'consents' ? 'active' : ''}`} onClick={() => setActiveNav('consents')}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M12 2 4 5v6c0 5 3.5 9 8 11 4.5-2 8-6 8-11V5l-8-3Z" /></svg>
              My Consents<span className="badge">{activeConsents}</span>
            </div>
            <div className={`navitem ${activeNav === 'records' ? 'active' : ''}`} onClick={() => setActiveNav('records')}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M6 3h9l4 4v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" /><path d="M14 3v4h4" /></svg>
              Accessible Records
            </div>
            <div className={`navitem ${activeNav === 'requests' ? 'active' : ''}`} onClick={() => setActiveNav('requests')}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M12 5v14M5 12h14" /></svg>
              New Request
            </div>
          </div>

          <div className="navgroup" style={{ borderTop: '1px solid var(--line)' }}>
            <h5>Account</h5>
            <div className={`navitem ${activeNav === 'schedule' ? 'active' : ''}`} onClick={() => setActiveNav('schedule')}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>
              Schedule
            </div>
            <div className={`navitem ${activeNav === 'audit' ? 'active' : ''}`} onClick={() => setActiveNav('audit')}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M3 7h18M3 12h18M3 17h18" /></svg>
              My Audit Trail
            </div>
            <div className={`navitem ${activeNav === 'settings' ? 'active' : ''}`} onClick={() => setActiveNav('settings')}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 0 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 0 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 0 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 0 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z" /></svg>
              Settings
            </div>
          </div>

          <div className="asidefoot">
            <div style={{ marginBottom: '10px' }}>
              <a href="/patient" style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 10px', borderRadius: '10px', fontSize: '12px', color: 'var(--ink-3)', fontFamily: 'var(--mono)', letterSpacing: '.1em', textTransform: 'uppercase', textDecoration: 'none' }}
                onMouseEnter={(event) => (event.currentTarget.style.color = 'var(--ink)')}
                onMouseLeave={(event) => (event.currentTarget.style.color = 'var(--ink-3)')}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 19l-7-7 7-7" /></svg>
                Patient Portal
              </a>
            </div>
            <div className="pill">
              <span className="dot" style={{ background: 'var(--coral)', boxShadow: '0 0 10px var(--coral)' }} />
              <span className="label">Network</span>
              <span className="val">TestNet</span>
            </div>
          </div>
        </aside>

        <main>
          <div className="topbar">
            <div>
              <div className="crumb">Doctor · {currentNavLabel}</div>
              <h1>Dr. <em style={{ fontStyle: 'italic', color: 'var(--coral)' }}>Hanwa, K.</em></h1>
            </div>
            <div className="search">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg>
              <input value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} placeholder="Search patients, records, consents…" />
              <span className="kbd">⌘ K</span>
            </div>
            <div className="topactions">
              <span className="chip">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M6 2v6a6 6 0 0 0 12 0V2" /><circle cx="18" cy="16" r="3" /></svg>
                DOC-4821
                <span className="tag" style={{ background: 'var(--coral)' }}>Clinician</span>
              </span>
              <button className="iconbtn" onClick={() => enqueueSnackbar('Clinical notifications are attached to the record queue.', { variant: 'info' })}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8" /><path d="M10 21a2 2 0 0 0 4 0" /></svg>
              </button>
              <div style={{ position: 'relative' }}>
                <button
                  className="avatar"
                  onClick={() => setShowLogoutMenu(!showLogoutMenu)}
                  style={{ background: 'var(--coral)', color: 'var(--ink)', fontFamily: 'var(--mono)', fontSize: '13px', fontWeight: '600', cursor: 'pointer', border: 'none' }}
                  title="Click to logout"
                >
                  KH
                </button>
                {showLogoutMenu && (
                  <div
                    style={{
                      position: 'absolute',
                      top: '100%',
                      right: 0,
                      marginTop: '8px',
                      background: 'var(--bg-2)',
                      border: '1px solid var(--line)',
                      borderRadius: '8px',
                      minWidth: '160px',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                      zIndex: 1000,
                    }}
                  >
                    <div style={{ padding: '8px 0' }}>
                      <div style={{ padding: '10px 14px', fontSize: '12px', color: 'var(--ink-2)' }}>
                        {activeAddress?.slice(0, 10)}...
                      </div>
                      <hr style={{ margin: '6px 0', borderColor: 'var(--line)' }} />
                      <button
                        onClick={handleLogout}
                        style={{
                          width: '100%',
                          padding: '10px 14px',
                          border: 'none',
                          background: 'transparent',
                          cursor: 'pointer',
                          fontSize: '13px',
                          color: 'var(--ink)',
                          textAlign: 'left',
                          transition: 'background 0.2s',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = 'var(--bg)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = 'transparent';
                        }}
                      >
                        🚪 Logout
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="content">
            {activeNav === 'overview' ? (
              <>
                <div className="hero">
                  <div className="greet reveal d1">
                    <div>
                      <div className="k">§ Clinician Overview · Live Snapshot</div>
                      <h2>
                        {activeConsents} consents <em>active</em>.
                        <br />{accessibleRecords.length} records in care.
                      </h2>
                      <p>{heroSummary} There are {requestQueue.filter((request) => request.status === 'pending').length} clinician requests waiting in the local queue.</p>
                    </div>
                    <div className="foot">
                      <button className="btn lime" onClick={() => setActiveNav('requests')}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14" /></svg>
                        Request access
                      </button>
                      <button className="btn ghost" onClick={() => openRecordViewer(accessibleRecords[0] ?? liveRecords[0] ?? medicalRecords[0])}>View records</button>
                      <button className="btn ghost" onClick={() => setActiveNav('audit')}>My audit log</button>
                    </div>
                  </div>
                  <div className="id reveal d2">
                    <div className="row">
                      <div>
                        <div className="mono">Clinician ID</div>
                        <h3>Dr. Hanwa, K.</h3>
                      </div>
                      <span className="tag" style={{ background: 'var(--coral)' }}>Clinician</span>
                    </div>
                    <div className="sid">DOC<em>–4821</em></div>
                    <div className="meta">
                      <span>Chain · <em>Algorand</em></span>
                      <span>Patients · <em>{activePatients}</em></span>
                    </div>
                  </div>
                </div>

                <div className="kpis">
                  <div className="kpi reveal d1" data-c="coral">
                <div className="top">
                  <div className="icn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></svg></div>
                  <span className="delta">{activePatients} patients</span>
                </div>
                <b>{activePatients}</b>
                <span className="lbl">My patients</span>
                <svg className="spark" viewBox="0 0 140 28" fill="none"><path d="M0 22 L20 18 L40 16 L60 12 L80 10 L100 8 L120 6 L140 4" stroke="var(--ink-green)" strokeWidth="1.5" /></svg>
              </div>
                  <div className="kpi reveal d2" data-c="lime">
                <div className="top">
                  <div className="icn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2 4 5v6c0 5 3.5 9 8 11 4.5-2 8-6 8-11V5l-8-3Z" /></svg></div>
                  <span className="delta">{activeConsents} granted</span>
                </div>
                <b>{activeConsents}</b>
                <span className="lbl">Active consents</span>
                <svg className="spark" viewBox="0 0 140 28" fill="none"><path d="M0 16 L20 14 L40 10 L60 12 L80 8 L100 10 L120 6 L140 4" stroke="var(--ink-green)" strokeWidth="1.5" /></svg>
              </div>
              <div className="kpi reveal d3" data-c="sky">
                <div className="top">
                  <div className="icn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 3h9l4 4v14H5V4Z" /><path d="M14 3v4h4" /></svg></div>
                  <span className="delta">{accessibleRecords.length} visible</span>
                </div>
                <b>{accessibleRecords.length}</b>
                <span className="lbl">Records accessible</span>
                <svg className="spark" viewBox="0 0 140 28" fill="none"><path d="M0 20 L20 16 L40 14 L60 12 L80 10 L100 8 L120 6 L140 4" stroke="var(--ink-green)" strokeWidth="1.5" /></svg>
              </div>
              <div className="kpi reveal d4" data-c="violet">
                <div className="top">
                  <div className="icn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg></div>
                  <span className="delta">{expiringConsents} expiring</span>
                </div>
                <b>{expiringConsents}</b>
                <span className="lbl">Expiring today</span>
                <svg className="spark" viewBox="0 0 140 28" fill="none"><path d="M0 8 L20 10 L40 8 L60 10 L80 12 L100 14 L120 18 L140 22" stroke="var(--ink-green)" strokeWidth="1.5" /></svg>
              </div>
            </div>

            <div className="grid">
              <div className="card reveal d1">
                <div className="head">
                  <div>
                    <h3>My consents</h3>
                    <div className="sub" style={{ marginTop: '4px' }}>{activeConsents} active · {pendingConsents} pending</div>
                  </div>
                  <div className="actions">
                    <div className="tabs">
                      <button className={activeTab === 'active' ? 'on' : ''} onClick={() => setActiveTab('active')}>Active</button>
                      <button className={activeTab === 'pending' ? 'on' : ''} onClick={() => setActiveTab('pending')}>Pending</button>
                      <button className={activeTab === 'expired' ? 'on' : ''} onClick={() => setActiveTab('expired')}>Expired</button>
                    </div>
                  </div>
                </div>
                <table className="tbl">
                  <thead>
                    <tr>
                      <th>Patient</th>
                      <th>Scope</th>
                      <th>Status</th>
                      <th>Remaining</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {filteredConsents.map((consent) => {
                      const patientRecord = patients.find((candidate) => candidate.id === consent.patientId) ?? patient;

                      return (
                        <tr key={consent.id}>
                          <td>
                            <div className="avn">
                              <div className="av" data-c={consent.grantedToColor}>{makeInitials(patientRecord.name)}</div>
                              <div>
                                <div className="nm">{patientRecord.name}</div>
                                <div className="rl">{patientRecord.shortId}</div>
                              </div>
                            </div>
                          </td>
                          <td style={{ fontFamily: 'var(--mono)', fontSize: '12px', color: 'var(--ink-2)', letterSpacing: '.06em' }}>{consent.scopeLabel}</td>
                          <td><span className={`pill-s ${consent.status}`}>{consent.status}</span></td>
                          <td>
                            {consent.status === 'active' ? (
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                                <span style={{ fontFamily: 'var(--mono)', fontSize: '11px', color: 'var(--ink)' }}>{consent.remaining}</span>
                                <div className="meter"><i style={{ width: `${consent.progressPct}%` }} /></div>
                              </div>
                            ) : (
                              <span style={{ fontFamily: 'var(--mono)', fontSize: '11px', color: 'var(--ink-3)' }}>{consent.remaining}</span>
                            )}
                          </td>
                          <td className="actions-cell">
                            {consent.status === 'active' && (
                              <button className="ibtn danger" title="Revoke consent" onClick={() => mutateConsent(consent.id, 'expired', 'Revoked from clinician dashboard')}>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
                              </button>
                            )}
                            {consent.status === 'pending' && (
                              <button className="ibtn" title="Approve consent" onClick={() => mutateConsent(consent.id, 'active', 'Approved from clinician dashboard')}>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m9 12 2 2 4-4" /></svg>
                              </button>
                            )}
                            {consent.status === 'expired' && (
                              <button className="ibtn" title="Renew consent" onClick={() => mutateConsent(consent.id, 'active', 'Renewed from clinician dashboard')}>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 12a9 9 0 0 1 15.95-5.67L21 9" /><path d="M21 3v6h-6" /><path d="M21 12a9 9 0 0 1-15.95 5.67L3 15" /><path d="M3 21v-6h6" /></svg>
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="card reveal d2">
                <div className="head">
                  <div>
                    <h3>Request queue</h3>
                    <div className="sub" style={{ marginTop: '4px' }}>{requestQueue.length} local requests · {requestQueue.filter((request) => request.status === 'pending').length} pending</div>
                  </div>
                </div>
                <div className="requests">
                  <div className="req" style={{ cursor: 'default' }}>
                    <div className="av" data-c="coral" style={{ width: '40px', height: '40px', borderRadius: '12px', flexShrink: 0 }}>DR</div>
                    <div className="body" style={{ display: 'grid', gap: '6px' }}>
                      <div className="t">Submit a new request</div>
                      <div className="d">SEND ACCESS REQUEST · CARE COORDINATION</div>
                      <div style={{ display: 'grid', gap: '8px' }}>
                        <input value={requestPatient} onChange={(event) => setRequestPatient(event.target.value)} placeholder="Patient short ID or name" style={{ width: '100%', padding: '10px 12px', borderRadius: '12px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '12px' }} />
                        <input value={requestScope} onChange={(event) => setRequestScope(event.target.value)} placeholder="Scope (for example LAB_RESULTS)" style={{ width: '100%', padding: '10px 12px', borderRadius: '12px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '12px' }} />
                        <textarea value={requestReason} onChange={(event) => setRequestReason(event.target.value)} rows={3} placeholder="Reason for the request" style={{ width: '100%', padding: '10px 12px', borderRadius: '12px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '12px', resize: 'vertical' }} />
                      </div>
                    </div>
                    <div className="acts">
                      <button className="approve" onClick={submitRequest}>Submit</button>
                    </div>
                  </div>

                  {filteredRequests.length > 0 ? filteredRequests.map((request) => (
                    <div className="req" key={request.id}>
                      <div className="av" data-c={request.status === 'approved' ? 'lime' : request.status === 'rejected' ? 'coral' : 'sky'} style={{ width: '40px', height: '40px', borderRadius: '12px', flexShrink: 0 }}>{makeInitials(request.patient.name)}</div>
                      <div className="body">
                        <div className="t">{request.patient.name}</div>
                        <div className="d">{request.scope}</div>
                        <div style={{ fontFamily: 'var(--mono)', fontSize: '9px', color: 'var(--ink-3)', letterSpacing: '.1em', marginTop: '4px' }}>{request.reason}</div>
                      </div>
                      <div className="acts">
                        {request.status === 'pending' ? (
                          <>
                            <button className="approve" onClick={() => updateRequestStatus(request.id, 'approved')}>Allow</button>
                            <button className="deny" onClick={() => updateRequestStatus(request.id, 'rejected')}>Deny</button>
                          </>
                        ) : (
                          <button className={request.status === 'approved' ? 'approve' : 'deny'}>{request.status}</button>
                        )}
                      </div>
                    </div>
                  )) : (
                    <div className="req" style={{ cursor: 'default' }}>
                      <div className="av" data-c="sky" style={{ width: '40px', height: '40px', borderRadius: '12px', flexShrink: 0 }}>--</div>
                      <div className="body">
                        <div className="t">No pending clinician requests</div>
                        <div className="d">QUEUE IS EMPTY</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="card reveal d3">
                <div className="head">
                  <div>
                    <h3>Prescription upload</h3>
                    <div className="sub" style={{ marginTop: '4px' }}>Encrypt a prescription, pin it to IPFS, and anchor it on-chain by patient ID.</div>
                  </div>
                </div>
                <div style={{ display: 'grid', gap: '16px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '11px', fontWeight: '600', color: 'var(--ink)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>Patient ID</label>
                    <input value={prescriptionTarget} onChange={(event) => setPrescriptionTarget(event.target.value)} placeholder="e.g., 847KOR" style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '13px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '11px', fontWeight: '600', color: 'var(--ink)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>Medication</label>
                    <input value={prescriptionMedication} onChange={(event) => setPrescriptionMedication(event.target.value)} placeholder="e.g., Amoxicillin 500mg" style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '13px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '11px', fontWeight: '600', color: 'var(--ink)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>Dosage & Frequency</label>
                    <input value={prescriptionDosage} onChange={(event) => setPrescriptionDosage(event.target.value)} placeholder="e.g., 1 tablet three times daily for 10 days" style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '13px' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '11px', fontWeight: '600', color: 'var(--ink)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>Patient Instructions</label>
                    <textarea value={prescriptionInstructions} onChange={(event) => setPrescriptionInstructions(event.target.value)} rows={3} placeholder="Take after meals and complete the full course." style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '13px', resize: 'vertical', fontFamily: 'inherit' }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: '11px', fontWeight: '600', color: 'var(--ink-2)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '6px' }}>Optional Notes</label>
                    <textarea value={prescriptionNotes} onChange={(event) => setPrescriptionNotes(event.target.value)} rows={2} placeholder="Add any additional notes..." style={{ width: '100%', padding: '10px 12px', borderRadius: '8px', border: '1px solid var(--line)', background: 'var(--bg)', fontSize: '13px', resize: 'vertical', fontFamily: 'inherit' }} />
                  </div>
                  <button className="btn lime" onClick={submitPrescription} disabled={prescriptionUploading} style={{ marginTop: '4px' }}>
                    {prescriptionUploading ? (
                      <><svg style={{ width: '14px', height: '14px', display: 'inline-block', marginRight: '6px', animation: 'spin 1s linear infinite' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></svg>Uploading…</>
                    ) : (
                      'Upload prescription'
                    )}
                  </button>
                  {prescriptionFeedback && (
                    <div style={{ padding: '10px 12px', borderRadius: '8px', background: prescriptionFeedback.includes('Error') || prescriptionFeedback.includes('Failed') ? 'rgba(220, 53, 69, 0.1)' : 'rgba(40, 167, 69, 0.1)', border: `1px solid ${prescriptionFeedback.includes('Error') || prescriptionFeedback.includes('Failed') ? 'rgba(220, 53, 69, 0.3)' : 'rgba(40, 167, 69, 0.3)'}`, fontFamily: 'var(--mono)', fontSize: '11px', color: prescriptionFeedback.includes('Error') || prescriptionFeedback.includes('Failed') ? 'var(--coral)' : 'var(--lime)', lineHeight: 1.6, wordBreak: 'break-word' }}>
                      {prescriptionFeedback}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="grid">
              <div className="card reveal d2">
                <div className="head">
                  <div>
                    <h3>Accessible records</h3>
                    <div className="sub" style={{ marginTop: '4px' }}>{accessibleRecords.length} consent-gated records</div>
                  </div>
                </div>
                <div className="recs">
                  {recentRecords.map((record) => {
                    const patientRecord = patients.find((candidate) => candidate.id === record.patientId) ?? patient;

                    return (
                      <div className="rec" data-c={record.color} key={record.id} onClick={() => openRecordViewer(record)}>
                        <div className="top">
                          <div className="icn">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                              {record.type === 'lab' && <path d="M10 2v6L4 18a2 2 0 0 0 2 3h12a2 2 0 0 0 2-3L14 8V2" />}
                              {record.type === 'imaging' && <><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M3 9h18M9 9v12" /></>}
                              {record.type === 'prescription' && <><path d="M6 3h9l4 4v14H5V4Z" /><path d="M14 3v4h4" /></>}
                              {record.type === 'discharge' && <path d="M9 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8l-5-5z" />}
                              {record.type === 'vaccination' && <path d="m18 2 4 4-4 4" />}
                              {record.type === 'vitals' && <path d="M3 12h4l3-9 4 18 3-9h4" />}
                            </svg>
                          </div>
                          <span className="chip-s">{recordTypeLabel[record.type]}</span>
                        </div>
                        <h4>{record.title}</h4>
                        <p>{patientRecord.name}</p>
                        <div className="cid">{record.ipfsHash}</div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '14px' }}>
                          <button className="ibtn" title="Share record" onClick={(event) => { event.stopPropagation(); setShareRecord(record); }}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="3" height="9" /><rect x="9.5" y="7" width="3" height="13" /><rect x="16" y="4" width="3" height="16" /></svg>
                          </button>
                          <button className="ibtn" title="Open record" onClick={(event) => { event.stopPropagation(); openRecordViewer(record); }}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="card reveal d2">
                <div className="head">
                  <div>
                    <h3>Schedule and audit</h3>
                    <div className="sub" style={{ marginTop: '4px' }}>{activityFeed.length} activity events</div>
                  </div>
                </div>
                <div className="audit">
                  {scheduleItems.map((item, index) => (
                    <div className="audit-item" key={`${item.label}-${index}`}>
                      <div className="pin" data-c={item.status === 'pending' ? 'sun' : 'lime'} />
                      <div className="body">
                        <div className="t"><em>{item.label}</em></div>
                        <div className="d">{item.detail}</div>
                      </div>
                      <time>{item.status}</time>
                    </div>
                  ))}
                  {activityFeed.slice(0, 4).map((entry) => (
                    <div className="audit-item" key={entry.id}>
                      <div className="pin" data-c={entry.color} />
                      <div className="body">
                        <div className="t"><em>{entry.actor}</em> · {entry.subject}</div>
                        <div className="d">{entry.detail}</div>
                      </div>
                      <time>{entry.timestamp}</time>
                    </div>
                  ))}
                </div>
              </div>
            </div>
              </>
            ) : renderDoctorTabContent()}
          </div>
        </main>
      </div>

      <UploadRecordModal
          isOpen={uploadModalOpen}
          onClose={() => setUploadModalOpen(false)}
          patientAddress={selectedPatientAddress}
          onSuccess={(cid) => {
            alert(`Record uploaded successfully! CID: ${cid.slice(0, 20)}...`);
            setUploadModalOpen(false);
          }}
        />

      {viewerRecords.length > 0 && (
        <RecordSlider
          records={viewerRecords}
          initialIndex={viewerIndex}
          onClose={() => setViewerRecords([])}
          onShare={(record) => setShareRecord(record)}
        />
      )}

      {shareRecord && (
        <QRModal
          record={shareRecord}
          patient={patients.find((candidate) => candidate.id === shareRecord.patientId) ?? patient}
          onClose={() => setShareRecord(null)}
        />
      )}
    </div>
  );
}
